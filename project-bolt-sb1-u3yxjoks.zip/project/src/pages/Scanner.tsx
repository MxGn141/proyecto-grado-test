import React, { useEffect, useState } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';

const Scanner: React.FC = () => {
  const [scanResult, setScanResult] = useState<string | null>(null);

  useEffect(() => {
    const scanner = new Html5QrcodeScanner('reader', {
      qrbox: {
        width: 250,
        height: 250,
      },
      fps: 5,
    });

    scanner.render(success, error);

    function success(result: string) {
      scanner.clear();
      setScanResult(result);
    }

    function error(err: any) {
      console.warn(err);
    }

    return () => {
      scanner.clear();
    };
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Escáner QR</h1>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
        <div className="max-w-2xl mx-auto">
          {scanResult ? (
            <div className="text-center">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                Código QR Escaneado
              </h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">{scanResult}</p>
              <button
                onClick={() => setScanResult(null)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
              >
                Escanear Otro
              </button>
            </div>
          ) : (
            <div>
              <div className="mb-4 text-center">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                  Escanea un Código QR
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  Coloca el código QR frente a la cámara
                </p>
              </div>
              <div id="reader" className="w-full"></div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Scanner;